//command_handler.h

#include "functions.h"

//------------------------------------------------------------------

void handleCommand(Node *new_node, Edge *new_edge, char *test_string);
//------------------------------------------------------------------
